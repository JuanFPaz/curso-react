# Clase 2

## Ejercitación Js

### Ejercicio 1

Tengo desarrollada la siguiente función en javascript

```js
function suma (a,b,callback){
    let c = a +b;
    callback( );
}
```

¿Que es el tercer parámetro recibido?
¿En que casos es obligatorio desarrollar este tipo de funciones?
Realizar un llamado a la función de ejemplo.

### Ejercicio 2

Ejercicio 2
Desarrollador una calculadora que tenga:

- 2 campos inputs para los operandos.
- 4 botones de operadores básicos (suma, resta, multiplicación, división).

Al realizar la cuenta se deberá actualizar el campo resultado.
