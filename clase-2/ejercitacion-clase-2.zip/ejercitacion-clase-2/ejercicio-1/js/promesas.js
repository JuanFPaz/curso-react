let promesa = new Promise(eventoBotones);


function eventoBotones(res,rej){
    const botonUno = document.getElementById("boton-uno");
    const botonDos = document.getElementById("boton-dos");

    botonUno.addEventListener("click",()=>{

    })
}