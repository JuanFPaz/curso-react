function suma(a, b, callback) {
    let c = a + b;
    callback(c);
}

function mostrarResulado(c) {
    const parrafo = document.getElementById("resultado")
    parrafo.innerHTML = `El resultado de la suma es ${c}`
}

suma(5, 5, mostrarResulado);

function mostrarResulado(c) {
    const parrafo = document.getElementById("resultado")
    parrafo.innerHTML = `El resultado de la suma es ${c}`
}

function mostrarError(c) {
    const parrafo = document.getElementById("resultado")
    parrafo.innerHTML = c;
}

{
    function suma(a, b) {
        return new Promise((res, rej) => {
            let c = a + b;
            if (c) {
                res(c);
            } else {
                rej("Error: No se pudo realizar la suma correctamente");
            }
        });
    }
    suma(5,5)
        .then((resultado) => {
            const resultadoPromesa = document.getElementById("resultadoPromesa");
            resultadoPromesa.innerHTML = resultado;
        })
        .catch((error) => {
            const errorPromesa = document.getElementById("errorPromesa");
            errorPromesa.innerHTML = error
        });
    suma(5)
        .then((resultado) => {
            const resultadoPromesa = document.getElementById("resultadoPromesa");
            resultadoPromesa.innerHTML = resultado;
        })
        .catch((error) => {
            const errorPromesa = document.getElementById("errorPromesa");
            errorPromesa.innerHTML = error
        });
}
