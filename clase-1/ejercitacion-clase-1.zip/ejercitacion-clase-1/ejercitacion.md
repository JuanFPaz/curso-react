# Clase 1

## Repaso HTML - CSS

### Consigna

Seguro No Pagamos Cooperativa es una compañía de seguros que lleva 2 años en el mercado.
Hasta el momento trabajan con los esquemas tradicionales de venta, es decir contacto
telefónico o a través de sus asesores con los potenciales clientes.
El directorio de la compañía se reunió con el departamento de sistemas para solicitarle un
desarrollo de un sitio web. El objetivo es que los futuros clientes puedan solicitar un contacto
a través de la web para que un asesor se contacte con ellos.
Vos como parte del equipo de desarrollo debes realizar el maquetado HTML de este sitio web,
dándole estilos al mismo con la utilización de CSS
Los datos que se deben solicitar son los siguientes:

- Nombre
- Apellido
- DNI
- Teléfono
- Tipo de seguro
    1. Básico
    2. Intermedio
    3. Premium

Al seleccionar el tipo de seguro (básico, intermedio, premium) se debera mostrar en pantalla el valor de cada uno:
1. Básico: `$500`
2. Intermedio: `$1000`
3. Premium: `$1500`